"""Small, transparent IRPF scenario model: individual employment income in Canarias.

2025 rules verified against AEAT on 2026-10-30. A 2026 request is explicitly a
projection of those rules; this module does not implement employer withholding.
Money is calculated with Decimal and rounded half up to cents at output.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

RULES_YEAR = 2025
VERIFIED_ON = "2026-10-30"
OFFICIAL_RETENTIONS = "https://sede.agenciatributaria.gob.es/Sede/Retenciones.shtml"
SOURCES = [
    {"title": "AEAT · Cuotas de colegios profesionales: requisitos y límite", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-ayuda-presentacion/irpf-2025/7-cumplimentacion-irpf/7_1-rendimientos-trabajo-personal/7_1_5-rendimiento-neto-trabajo-gastos-deducibles.html"},
    {"title": "AEAT · Escala estatal 2025", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-practicos/irpf-2025/c15-calculo-impuesto-determinacion-cuotas-integras/gravamen-base-liquidable-general/gravamen-estatal.html"},
    {"title": "AEAT · Escalas autonómicas 2025 (Canarias)", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-ayuda-presentacion/irpf-2025/8-cumplimentacion-irpf/8_4-cuota-integra/8_4_3-gravamen-base-liquidable-general/8_4_3_2-cuota-integra-autonomica.html"},
    {"title": "AEAT · Mínimos personales y familiares 2025", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-practicos/irpf-2025/c14-adecuacion-impuesto-circunstancias-personales/minimo-autonomico-personal-familiar/cuadro-minimos-personales-familiares-estatal-autonomicos.html"},
    {"title": "AEAT · Reducción de los rendimientos del trabajo 2025", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-practicos/irpf-2025/c03-rendimientos-trabajo/rendimiento-neto-trabajo-integrar-base-imponible/fase-3-determinacion-rendimiento-neto-reducido.html"},
    {"title": "AEAT · Gastos generales del trabajo (2.000 euros)", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-practicos/irpf-2025/c03-rendimientos-trabajo/rendimiento-neto-trabajo-integrar-base-imponible/fase-2-determinacion-rendimiento-neto/particular-analisis-gastos-articulo-19_2_f-lirpf.html"},
    {"title": "AEAT · Deducción por rendimientos del trabajo 2025", "url": "https://sede.agenciatributaria.gob.es/Sede/ayuda/manuales-videos-folletos/manuales-practicos/irpf-2025/c18-cuota-liquida-resultante-autoliquidacion/deducciones-cuota-liquida-total/deduccion-obtencion-rendimientos-trabajo.html"},
    {"title": "AEAT · Cálculo oficial de retenciones (ejercicio vigente)", "url": OFFICIAL_RETENTIONS},
]

# Lower bound, published accumulated quota, marginal rate. Using the published
# quotas preserves the official rounding at Canary bracket transitions.
STATE_SCALE = [("0", "0", ".095"), ("12450", "1182.75", ".12"),
               ("20200", "2112.75", ".15"), ("35200", "4362.75", ".185"),
               ("60000", "8950.75", ".225"), ("300000", "62950.75", ".245")]
CANARY_SCALE = [("0", "0", ".09"), ("13748", "1237.32", ".115"),
                ("19422", "1889.83", ".14"), ("35924", "4200.11", ".185"),
                ("57566", "8203.88", ".235"), ("93268", "16593.85", ".25"),
                ("123745", "24213.10", ".26")]
D = Decimal
ZERO = D(0)


def money(value):
    return float(value.quantize(D(".01"), rounding=ROUND_HALF_UP))


def _number(payload, key, default=0, maximum=100000000):
    raw = payload.get(key, default)
    if raw is None or isinstance(raw, bool):
        raise ValueError(f"El campo {key} debe ser numérico.")
    try:
        result = D(str(raw))
    except (InvalidOperation, ValueError):
        raise ValueError(f"El campo {key} debe ser numérico.") from None
    if not result.is_finite() or result < 0 or result > D(str(maximum)):
        raise ValueError(f"El campo {key} debe estar entre 0 y {maximum}.")
    return result


def _integer(payload, key, default, maximum):
    result = _number(payload, key, default, maximum)
    if result != result.to_integral_value():
        raise ValueError(f"El campo {key} debe ser un número entero.")
    return int(result)


def _scale(base, scale):
    base = max(ZERO, base)
    for floor, quota, rate in reversed(scale):
        if base >= D(floor):
            return D(quota) + (base - D(floor)) * D(rate)
    return ZERO


def work_reduction(net_before_general_expense, other_income):
    """Art.20 uses net income BEFORE the general 2,000-euro expense."""
    value = max(ZERO, D(str(net_before_general_expense)))
    if D(str(other_income)) > D(6500) or value >= D("19747.5"):
        return ZERO
    if value <= D(14852):
        return D(7302)
    if value <= D("17673.52"):
        return max(ZERO, D(7302) - D("1.75") * (value - D(14852)))
    return max(ZERO, D("2364.34") - D("1.14") * (value - D("17673.52")))


def metadata():
    return {
        "rules_year": RULES_YEAR, "verified_on": VERIFIED_ON,
        "regions": [{"value": "canarias", "label": "Canarias"}],
        "supported_years": [2025, 2026], "projection_years": [2026],
        "scope": "Tributación individual, rentas del trabajo y otras rentas netas positivas de la base general; residencia fiscal en Canarias.",
        "sources": SOURCES,
        "official_retentions_url": OFFICIAL_RETENTIONS,
    }


def _unsupported(year, message, requires_profile=False):
    return {
        **metadata(), "tax_year": year, "is_projection": year != RULES_YEAR,
        "supported": False, "requires_profile": requires_profile,
        "warnings": [message], "estimated_tax": None, "balance": None,
        "target_rate_remaining": None, "remaining_withholding": None,
        "withholding_per_payment": None, "effective_rate": None,
        "breakdown": {},
    }


def simulate(payload):
    """Return an explicit annual scenario, without inventing a personal profile.

    Required personal field: age (age at 31 December of the requested year).
    A child entry is an ELIGIBLE descendant, oldest first, with age and share
    (0.5 or 1). Eligibility (income, cohabitation, own return) is user-confirmed.
    deductible_expenses is art.19.2.f (default 2000); other_work_expenses covers
    validated art.19.2.a-e expenses other than annual_ss. reductions is a
    user-validated base reduction, not an automatic pension contribution limit.
    balance >0 means to pay AFTER planned future withholdings; <0 refund.
    """
    if not isinstance(payload, dict):
        raise ValueError("La simulación requiere un objeto con los datos del escenario.")
    year = _integer(payload, "year", 2026, 2100)
    if year not in (2025, 2026):
        return _unsupported(year, "Este ejercicio no tiene reglas fiscales verificadas. El histórico de nóminas sigue disponible; la simulación admite 2025 y una proyección de 2026 con reglas de 2025.")
    if str(payload.get("region", "")).strip().lower() not in ("canarias", "canary_islands"):
        return _unsupported(year, "Selecciona Canarias. No se aplican escalas de otra comunidad autónoma sin verificar su normativa.", True)
    if payload.get("age") in (None, ""):
        return _unsupported(year, "Completa tu edad a 31 de diciembre y revisa las circunstancias familiares antes de calcular.", True)
    age = _integer(payload, "age", None, 120)
    if age < 16:
        return _unsupported(year, "La simulación solo contempla contribuyentes de 16 años o más.", True)
    if payload.get("filing", "individual") != "individual":
        return _unsupported(year, "La tributación conjunta requiere otro cálculo; este simulador solo contempla declaración individual.")
    if payload.get("disability") or payload.get("ascendants") or payload.get("special_regime"):
        return _unsupported(year, "El cálculo automático no contempla discapacidad, ascendientes a cargo ni regímenes especiales. Revisa este escenario con el simulador oficial de la AEAT.")

    gross = _number(payload, "annual_gross")
    ss = _number(payload, "annual_ss")
    withheld = _number(payload, "withheld")
    remaining_gross = _number(payload, "remaining_gross")
    remaining_payments = _integer(payload, "remaining_payments", 0, 36)
    planned_rate = _number(payload, "planned_remaining_rate", 0, 100)
    other_general = _number(payload, "other_general_income")
    # This includes the net other_general_income and other non-exempt income
    # (e.g. savings) for the Art.20 threshold, even though savings is not taxed
    # by this general-income-only model. It may never understate other_general.
    other_for_reduction = max(other_general, _number(payload, "other_income_for_reduction", other_general))
    work_expenses = _number(payload, "other_work_expenses")
    professional_fee = _number(payload, "professional_fee")
    # The entered amount is the deductible fee; zero explicitly disables it.
    applied_professional_fee = min(professional_fee, D(500))
    # The specific fee replaces generic other-work expenses, avoiding duplication.
    if "professional_fee" in payload:
        work_expenses = applied_professional_fee
    general_expenses_input = _number(payload, "deductible_expenses", 2000)
    reductions = _number(payload, "reductions")
    state_deductions = _number(payload, "state_deductions")
    regional_deductions = _number(payload, "regional_deductions")
    if ss + work_expenses > gross:
        raise ValueError("La Seguridad Social y los gastos del trabajo no pueden superar los rendimientos íntegros en este modelo.")
    if remaining_gross > gross:
        raise ValueError("El bruto pendiente no puede superar el bruto anual previsto.")

    warnings = [
        "Estimación orientativa de la declaración individual. El porcentaje sugerido equilibra este escenario; no reproduce el tipo de retención que debe calcular la empresa con el algoritmo AEAT.",
        "No incluye rentas del ahorro, ganancias patrimoniales, inmuebles, actividad económica, anualidades por alimentos, maternidad ni otras deducciones reembolsables. Las deducciones y reducciones manuales deben estar verificadas y dentro de sus límites legales.",
        "El bruto anual debe contener solo rendimientos íntegros sujetos a IRPF (incluidas las retribuciones en especie); no deben añadirse dietas u otros importes exentos.",
    ]
    if year != RULES_YEAR:
        warnings.insert(0, "PROYECCIÓN 2026 CON REGLAS DE 2025: no es un cálculo de Renta 2026 verificado. Comprueba los cambios normativos antes de solicitar una retención.")
    if professional_fee:
        warnings.append("La cuota colegial se resta como gasto del trabajo, no directamente de la cuota del impuesto. Introduce solo cuotas que cumplan los requisitos fiscales; si no corresponde descontarlas, indica 0 euros.")
    if professional_fee > 500:
        warnings.append("Se aplica el límite anual de 500 euros a la cuota colegial.")
    if general_expenses_input != 2000:
        warnings.append("Has modificado el gasto general de 2.000 euros. Los incrementos especiales y su elegibilidad no se verifican automáticamente.")
    if other_for_reduction > other_general:
        warnings.append("Has indicado otras rentas para comprobar las reducciones, pero no tributan en este cálculo salvo las incluidas en otras rentas de la base general. El resultado no es la cuota total de tu renta.")
    if remaining_gross and not remaining_payments:
        warnings.append("Hay bruto pendiente y cero pagas pendientes: revisa el calendario. No se calcula retención por paga.")
    if remaining_payments and not remaining_gross:
        warnings.append("Hay pagas pendientes y bruto pendiente igual a cero: no se puede calcular un porcentaje sobre esas pagas.")

    state_minimum, regional_minimum = D(5550), D(5606)
    # Completed age at year end (AEAT also describes these as age >=65/75).
    if age >= 65:
        state_minimum += D(1150)
        regional_minimum += D(1162)
    if age >= 75:
        state_minimum += D(1400)
        regional_minimum += D(1414)
    children = payload.get("children", [])
    if not isinstance(children, list) or len(children) > 20:
        raise ValueError("Los descendientes deben ser una lista de hasta 20 elementos.")
    eligible_children = []
    for child in children:
        if not isinstance(child, dict):
            raise ValueError("Cada descendiente debe incluir edad y proporción del mínimo.")
        child_age = _integer(child, "age", None, 120)
        share = _number(child, "share", 0.5, 1)
        if share not in (D("0.5"), D(1)):
            raise ValueError("El mínimo por descendiente debe repartirse al 50% o al 100%.")
        if child_age >= 25 or child.get("disability"):
            return _unsupported(year, "Los descendientes de 25 años o más o con discapacidad requieren revisar circunstancias que este modelo no contempla.")
        eligible_children.append((child_age, share))
    # Descendant order is by age, oldest first; third/fourth minimum depends
    # on order and cannot depend on the order of entries in the user interface.
    eligible_children.sort(key=lambda item: item[0], reverse=True)
    for index, (child_age, share) in enumerate(eligible_children):
        state_child = [2400, 2700, 4000, 4500][min(index, 3)]
        regional_child = [2424, 2727, 4040, 4545][min(index, 3)]
        state_minimum += (D(state_child) + (D(2800) if child_age < 3 else ZERO)) * share
        regional_minimum += (D(regional_child) + (D(2828) if child_age < 3 else ZERO)) * share
    if children:
        warnings.append("Solo incluye descendientes con derecho al mínimo: deben cumplirse los requisitos de edad, convivencia/dependencia, rentas y declaración propia. El programa no verifica estos requisitos ni fallecimientos durante el año.")

    net_before_general = gross - ss - work_expenses
    general_expenses = min(general_expenses_input, max(ZERO, net_before_general))
    net_work = max(ZERO, net_before_general - general_expenses)
    reduction = min(net_work, work_reduction(net_before_general, other_for_reduction))
    reduced_work = max(ZERO, net_work - reduction)
    base_before_reductions = reduced_work + other_general
    applied_reductions = min(reductions, base_before_reductions)
    base = max(ZERO, base_before_reductions - applied_reductions)
    state_quota = max(ZERO, _scale(base, STATE_SCALE) - _scale(min(base, state_minimum), STATE_SCALE))
    regional_quota = max(ZERO, _scale(base, CANARY_SCALE) - _scale(min(base, regional_minimum), CANARY_SCALE))
    applied_state_deductions = min(state_deductions, state_quota)
    applied_regional_deductions = min(regional_deductions, regional_quota)
    liquid = state_quota + regional_quota - applied_state_deductions - applied_regional_deductions

    # DA 61 employment-income deduction introduced in 2025. Here all gross work
    # income is assumed to arise from an effective employment/statutory service.
    work_deduction = ZERO
    if gross < D(18276) and other_for_reduction <= D(6500):
        requested = max(ZERO, D(340) - D(".2") * max(ZERO, gross - D(16576)))
        proportional_limit = (state_quota + regional_quota) * reduced_work / base_before_reductions if base_before_reductions else ZERO
        work_deduction = min(requested, proportional_limit, liquid)
        if gross:
            warnings.append("La deducción por rendimientos del trabajo presupone salario por prestación efectiva de servicios; no se aplica automáticamente a pensiones o prestaciones por desempleo.")
    estimated_tax = max(ZERO, liquid - work_deduction)
    future_withholding = remaining_gross * planned_rate / 100
    balance = estimated_tax - withheld - future_withholding
    needed = max(ZERO, estimated_tax - withheld)
    target_rate = needed / remaining_gross * 100 if remaining_gross else None
    if target_rate is not None and target_rate > 100:
        warnings.append("La cuota pendiente supera el bruto pendiente: ninguna retención de hasta 100% cubre este escenario. Revisa los importes y prevé la diferencia al presentar la renta.")
    if not remaining_gross and needed > 0:
        warnings.append("No quedan rendimientos sobre los que retener; la diferencia estimada quedaría para la declaración.")
    return {
        **metadata(), "tax_year": year, "is_projection": year != RULES_YEAR,
        "supported": True, "requires_profile": False, "region": "canarias",
        "estimated_tax": money(estimated_tax), "balance": money(balance),
        "balance_label": "a ingresar" if balance > 0 else "a devolver" if balance < 0 else "equilibrado",
        "target_rate_remaining": money(target_rate) if target_rate is not None else None,
        "remaining_withholding": money(needed),
        "withholding_per_payment": money(needed / remaining_payments) if remaining_payments else None,
        "effective_rate": money(estimated_tax / gross * 100) if gross else 0,
        "planned_future_withholding": money(future_withholding),
        "assumed_remaining_rate": money(planned_rate),
        "warnings": warnings,
        "breakdown": {
            "professional_fee_paid": money(professional_fee),
            "professional_fee_applied": money(applied_professional_fee),
            "annual_gross": money(gross), "social_security": money(ss),
            "other_work_expenses": money(work_expenses), "general_expenses": money(general_expenses),
            "net_work_before_general_expenses": money(net_before_general), "net_work": money(net_work),
            "work_reduction": money(reduction), "reduced_work_income": money(reduced_work),
            "other_general_income": money(other_general), "base_reductions": money(applied_reductions),
            "taxable_base": money(base), "state_minimum": money(state_minimum),
            "regional_minimum": money(regional_minimum), "state_quota": money(state_quota),
            "regional_quota": money(regional_quota), "state_deductions": money(applied_state_deductions),
            "regional_deductions": money(applied_regional_deductions), "employment_deduction": money(work_deduction),
            "withheld": money(withheld), "remaining_gross": money(remaining_gross),
            "remaining_payments": remaining_payments,
        },
    }
