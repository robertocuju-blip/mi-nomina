"""Local extraction of known Type3 outlines with no Unicode mapping.

The catalog stores only outline hashes, characters and advance metrics; it has
no receipt values or font programs. Every glyph must match exactly. Original
PDFs are never modified. Explicit PDF text positions rebuild the visual rows,
which pypdf's normal layout cannot reliably reconstruct for these Type3 fonts.
"""
import hashlib
import json
import math
from pathlib import Path
from pypdf.generic import ContentStream

IDENTITY = [1, 0, 0, 1, 0, 0]


def _multiply(m, n):
    return [m[0]*n[0]+m[1]*n[2], m[0]*n[1]+m[1]*n[3],
            m[2]*n[0]+m[3]*n[2], m[2]*n[1]+m[3]*n[3],
            m[4]*n[0]+m[5]*n[2]+n[4], m[4]*n[1]+m[5]*n[3]+n[5]]


def _font_map(font, catalog):
    if font.get('/Subtype') != '/Type3' or '/ToUnicode' in font:
        return None
    if [float(v) for v in font.get('/FontMatrix', [])] != IDENTITY:
        return None
    glyphs = font.get('/CharProcs')
    encoding = font.get('/Encoding')
    if glyphs is None or encoding is None:
        return None
    mapped = {}
    for name, reference in glyphs.get_object().items():
        digest = hashlib.sha256(b' '.join(reference.get_object().get_data().split())).hexdigest()
        if digest not in catalog:
            return None
        mapped[str(name)] = catalog[digest]
    codes, code = {}, 0
    for value in encoding.get_object().get('/Differences', []):
        if isinstance(value, int):
            code = value
        else:
            if str(value) not in mapped or not 0 <= code <= 255:
                return None
            codes[code] = mapped[str(value)]
            code += 1
    return codes or None


def _page_layout(page, reader, fonts):
    ctm = IDENTITY[:]
    tm = IDENTITY[:]
    lm = IDENTITY[:]
    stack, nodes = [], []
    font = None
    size, spacing, word, scale, leading, rise = 1, 0, 0, 1, 0, 0
    resources = page['/Resources']['/Font']

    def show(value):
        nonlocal tm
        data = value.original_bytes
        selected = resources[font].get_object()
        first = int(selected['/FirstChar'])
        widths = selected['/Widths']
        for code in data:
            if code not in fonts[font]:
                raise ValueError('Carácter Type3 desconocido.')
            entry = fonts[font][code]
            matrix = _multiply(_multiply([1,0,0,1,0,rise], tm), ctm)
            if abs(matrix[1]) > .001 or abs(matrix[2]) > .001 or matrix[0] <= 0 or matrix[3] <= 0:
                raise ValueError('Texto Type3 girado o reflejado no compatible.')
            em = size * math.hypot(matrix[0], matrix[1])
            nodes.append((matrix[4], matrix[5], entry['text'], em*entry['width']/1000, em))
            width = float(widths[code-first])
            advance = (width*size + spacing + (word if code == 32 else 0))*scale
            tm = _multiply([1,0,0,1,advance,0], tm)

    for args, op in ContentStream(page.get_contents(), reader).operations:
        if op == b'q':
            stack.append((ctm[:],font,size,spacing,word,scale,leading,rise))
        elif op == b'Q':
            ctm,font,size,spacing,word,scale,leading,rise = stack.pop()
        elif op == b'cm':
            ctm = _multiply([float(v) for v in args], ctm)
        elif op == b'BT':
            tm = IDENTITY[:]; lm = IDENTITY[:]
        elif op == b'Tf':
            font, size = str(args[0]), float(args[1])
        elif op == b'Tm':
            tm = [float(v) for v in args]; lm = tm[:]
        elif op in (b'Td', b'TD'):
            x,y = map(float,args)
            if op == b'TD': leading = -y
            lm = _multiply([1,0,0,1,x,y],lm); tm=lm[:]
        elif op == b'Tc': spacing=float(args[0])
        elif op == b'Tw': word=float(args[0])
        elif op == b'Tz':
            scale=float(args[0])/100
            if scale != 1: raise ValueError('Escala horizontal Type3 no compatible.')
        elif op == b'TL': leading=float(args[0])
        elif op == b'Ts': rise=float(args[0])
        elif op == b'T*':
            lm=_multiply([1,0,0,1,0,-leading],lm);tm=lm[:]
        elif op == b'Tj': show(args[0])
        elif op in (b'TJ',b"'",b'"'):
            raise ValueError('Operador de texto Type3 no compatible.')
    rows=[]
    for node in sorted(nodes,key=lambda n:(-n[1],n[0])):
        if not rows or abs(rows[-1][0][1]-node[1]) > 3:
            rows.append([])
        rows[-1].append(node)
    lines=[]
    for row in rows:
        line='';last=None
        for x,y,char,width,em in sorted(row):
            gap=x-last if last is not None else 0
            if gap > em*.8: line+=' '*max(2,round(gap/(em*.4)))
            elif gap > em*.18: line+=' '
            line+=char;last=x+width
        lines.append(line)
    return '\n'.join(lines)


def extract_known_type3(reader):
    """Return all pages only if their font outlines and text operators are known."""
    if not any(ref.get_object().get('/Subtype') == '/Type3'
               for page in reader.pages for ref in page.get('/Resources',{}).get('/Font',{}).values()):
        return None
    catalog=json.loads(Path(__file__).with_name('type3_glyphs.json').read_text(encoding='utf-8'))
    pages=[]
    try:
        for page in reader.pages:
            fonts={name:_font_map(ref.get_object(),catalog) for name,ref in page['/Resources']['/Font'].items()}
            if not fonts or any(value is None for value in fonts.values()): return None
            pages.append(_page_layout(page,reader,fonts))
    except (ValueError,KeyError,TypeError,IndexError):
        return None
    return '\n\n'.join(pages)
