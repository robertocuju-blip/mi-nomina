"""Validated annual numeric parameters. No executable expressions from users."""
import copy
import hashlib
import json
from pathlib import Path
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlparse

CATALOG = json.loads(Path(__file__).with_name('tax_rules.json').read_text(encoding='utf-8'))


def validate_rules(value, year=None):
    if not isinstance(value, dict) or value.get('schema_version') != 1:
        raise ValueError('La normativa debe usar el formato de esta aplicación.')
    result = copy.deepcopy(value)
    def number(container, key, maximum=100000000, integer=False):
        labels = {'general_expense':'gasto general', 'professional_fee_limit':'límite de cuota colegial', 'year':'ejercicio', 'limit':'límite del tramo', 'rate':'tipo del tramo', 'maximum':'importe máximo', 'base':'mínimo general', 'first_threshold':'primer umbral', 'second_threshold':'segundo umbral', 'end_threshold':'umbral final', 'full_until':'salario con deducción completa', 'factor':'multiplicador', 'first_factor':'primer multiplicador', 'second_factor':'segundo multiplicador', 'second_amount':'importe del último intervalo', 'other_income_limit':'límite de otras rentas', 'amount':'importe por descendiente', 'child_age_limit':'edad límite de descendientes'}
        label = labels.get(key, key.replace('_', ' '))
        raw = container.get(key)
        if isinstance(raw, bool) or raw is None or raw == '':
            raise ValueError(f'Completa el parámetro {label}.')
        try:
            n = Decimal(str(raw))
        except Exception:
            raise ValueError(f'Revisa el parámetro {label}: debe ser numérico.') from None
        if not n.is_finite() or n < 0 or n > maximum or (integer and n != n.to_integral_value()):
            raise ValueError(f'El parámetro {label} está fuera del intervalo permitido.')
        container[key] = int(n) if integer else float(n)
        return n
    number(result, 'year', 2100, True)
    if result['year'] < 2022 or (year is not None and result['year'] != year):
        raise ValueError('El año de la normativa no coincide con el ejercicio.')
    if result.get('region') != 'canarias':
        raise ValueError('Este motor solo contempla residencia fiscal en Canarias.')
    for key in ('general_expense', 'professional_fee_limit'):
        number(result, key)
    number(result, 'child_age_limit', 120, True)
    for key in ('state_scale', 'regional_scale'):
        rows = result.get(key)
        if not isinstance(rows, list) or not 1 <= len(rows) <= 20:
            raise ValueError('Cada escala debe tener entre 1 y 20 tramos.')
        previous = Decimal(0)
        for i, row in enumerate(rows):
            if not isinstance(row, dict):
                raise ValueError('Hay un tramo sin datos válidos.')
            number(row, 'rate', 100)
            if i == len(rows)-1:
                if row.get('limit') is not None:
                    raise ValueError('El último tramo debe ser «En adelante».')
            else:
                upper = number(row, 'limit')
                if upper <= previous:
                    raise ValueError('Los límites de los tramos deben estar ordenados de menor a mayor, sin repetirse.')
                previous = upper
    for key in ('state_minimum', 'regional_minimum'):
        group = result.get(key)
        if not isinstance(group, dict):
            raise ValueError('Faltan los mínimos personales y familiares.')
        for field in ('base', 'increase_first', 'increase_second', 'young_increase'):
            number(group, field)
        for field in ('age_first', 'age_second', 'young_age'):
            number(group, field, 120, True)
        if group['age_second'] < group['age_first']:
            raise ValueError('La segunda edad del mínimo no puede ser menor que la primera.')
        if not isinstance(group.get('children'), list) or len(group['children']) != 4:
            raise ValueError('Completa los cuatro importes del mínimo por descendientes.')
        for i, amount in enumerate(group['children']):
            item = {'amount': amount}
            number(item, 'amount')
            group['children'][i] = item['amount']
    for key, fields in {
        'work_reduction': ('other_income_limit', 'first_threshold', 'second_threshold', 'end_threshold', 'maximum', 'first_factor', 'second_amount', 'second_factor'),
        'employment_deduction': ('other_income_limit', 'full_until', 'end_threshold', 'maximum', 'factor'),
    }.items():
        group = result.get(key)
        if not isinstance(group, dict):
            raise ValueError('Faltan parámetros de la reducción o deducción por trabajo.')
        for field in fields:
            number(group, field, 100 if 'factor' in field else 100000000)
        limits = [group[k] for k in (('first_threshold', 'second_threshold', 'end_threshold') if key == 'work_reduction' else ('full_until', 'end_threshold'))]
        if limits != sorted(limits) or len(set(limits)) != len(limits):
            raise ValueError('Los umbrales de reducción o deducción deben estar ordenados y ser distintos.')
    if not isinstance(result.get('sources'), list) or not 1 <= len(result['sources']) <= 12:
        raise ValueError('Añade al menos una fuente de la normativa.')
    for source in result['sources']:
        if not isinstance(source, dict) or not isinstance(source.get('title'), str) or not 1 <= len(source['title'].strip()) <= 240:
            raise ValueError('Cada fuente necesita un título.')
        url = source.get('url')
        if not isinstance(url, str) or len(url) > 2000 or urlparse(url).scheme != 'https' or not urlparse(url).hostname:
            raise ValueError('Cada fuente necesita un enlace HTTPS válido.')
    if not isinstance(result.get('notes', ''), str) or len(result.get('notes', '')) > 4000:
        raise ValueError('Las notas son demasiado largas.')
    # Ignore unrecognised keys and untrusted claims of verification.
    keys = ('schema_version', 'year', 'region', 'general_expense', 'professional_fee_limit', 'child_age_limit', 'state_scale', 'regional_scale', 'state_minimum', 'regional_minimum', 'work_reduction', 'employment_deduction', 'sources', 'notes')
    return {key: result.get(key, '') for key in keys}


def rules_for(year, custom=None):
    raw = custom if custom is not None else CATALOG['years'].get(str(year))
    return validate_rules(raw, year) if raw is not None else None


def rules_fingerprint(rules):
    return hashlib.sha256(json.dumps(rules, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()


def scale_rows(rows):
    floor = quota = Decimal(0)
    result = []
    for row in rows:
        rate = Decimal(str(row['rate'])) / 100
        result.append((str(floor), str(quota), str(rate)))
        if row['limit'] is not None:
            upper = Decimal(str(row['limit']))
            quota = (quota + (upper-floor)*rate).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
            floor = upper
    return result
