"""Local, auditable payroll extraction for the supplied Spanish payroll formats.

Money is read from the receipt, never inferred from annual accumulated figures.
Unknown/unreadable documents remain visible with null totals and require review.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import date
from pathlib import Path

from pypdf import PdfReader

PARSER_VERSION = "1.0.2"
MONEY = r"[-+]?(?:\d{1,3}(?:\.\d{3})+|\d+),\d{1,2}(?!\d)|[-+]?\d+\.\d{1,2}(?!\d)"
MONEY_RE = re.compile(MONEY)


def _fold(value):
    return "".join(c for c in unicodedata.normalize("NFKD", value) if not unicodedata.combining(c)).lower()


def _money(value):
    value = value.strip().replace(" ", "")
    return float(value.replace(".", "").replace(",", ".") if "," in value else value)


def _numbers(value):
    return [_money(m.group()) for m in MONEY_RE.finditer(value)]


def _iso(value):
    try:
        d, m, y = map(int, value.split("/"))
        return date(y, m, d).isoformat()
    except (TypeError, ValueError):
        return ""


def _item(concept, amount, kind, units=None, rate=None, base=None, price=None):
    return {"concept": concept.strip(), "kind": kind, "amount": round(amount, 2),
            "units": units, "rate": rate, "base": base, "price": price}


def _blank(path):
    name = re.match(r"(20\d{2})(0[1-9]|1[0-2])", path.stem)
    year = int(name[1]) if name else (int(path.parent.name) if path.parent.name.isdigit() else 0)
    month = int(name[2]) if name else 0
    return dict(year=year, month=month, payment_date="", period_start="", period_end="",
                employer="", employee="", category="", pay_type="ordinaria", days=None, days_contributed=None,
                gross=None, net=None, deductions=None, irpf_base=None, irpf_amount=None,
                irpf_rate=None, ss_employee=None, ss_base=None, ss_employer=None,
                remuneration_total=None, exempt_in_kind=None, in_kind_cotization=None,
                items=[], raw_text="", raw_layout="", warnings=[], parser_version=PARSER_VERSION,
                status="review", format="unknown")


def _dates(r, text, layout):
    # Prefer actual liquidation dates; names only establish the archive month.
    m = re.search(r"(\d{1,2}/\d{1,2}/20\d{2})\s*(?:a|-)\s*(\d{1,2}/\d{1,2}/20\d{2})", text)
    if not m:
        m = re.search(r"(\d{1,2}/\d{1,2}/20\d{2})\s*(?:a|-)\s*(\d{1,2}/\d{1,2}/20\d{2})", layout)
    if m:
        r["period_start"], r["period_end"] = _iso(m[1]), _iso(m[2])
    else:
        m = re.search(r"(\d{1,2})\.(\d{1,2})\s+a\s+(\d{1,2})\.(\d{1,2})\.(20\d{2})", text)
        if m:
            r["period_start"] = _iso(f"{m[1]}/{m[2]}/{m[5]}")
            r["period_end"] = _iso(f"{m[3]}/{m[4]}/{m[5]}")
    # Do not label period end as payment date when the receipt has no payment date.
    if r["period_end"]:
        py, pm = map(int, r["period_end"].split("-")[:2])
        if r["year"] and r["month"] and (r["year"], r["month"]) != (py, pm):
            r["warnings"].append("El periodo del PDF no coincide con el mes indicado en el nombre del archivo.")
        if not r["month"]:
            r["year"], r["month"] = py, pm


def _navarra_old(r, text, layout):
    r["format"] = "navarra_classic"
    r["employer"] = "Clínica Universidad de Navarra"
    lines = text.splitlines()
    r["employee"] = lines[1].strip() if len(lines) > 1 else ""
    r["category"] = re.sub(r"^\d+\s+", "", lines[2].strip()) if len(lines) > 2 else ""
    m = re.search(r"Cl[ií]nica Universidad de Navarra\s*\n(\d+)", text)
    if m:
        r["days"] = float(m[1])
    body = []
    started = False
    for line in layout.splitlines():
        f = _fold(line)
        if "salario base" in f:
            started = True
        if started and "las cantidades" in f:
            break
        if started:
            body.append(line)
    for line in body:
        # The May 2023 receipt prints an extra calculation line for the same salary.
        if line.lstrip().startswith("+") or re.search(r"Salario Base\s+1\s+\+", line):
            continue
        m = re.match(r"\s*([A-Za-zÁÉÍÓÚÜÑáéíóúüñ].*?)\s{2,}(.+)$", line)
        if not m:
            continue
        concept, rest = m.groups()
        nums = _numbers(rest)
        if not nums:
            continue
        f = _fold(concept)
        if "informativo" in f or "total cot retribucion" in f:
            kind = "informative"
        elif "irpf" in f or "cotizacion" in f or "exceso defecto" in f:
            kind = "deduction"
        else:
            kind = "earning"
        amount = nums[-1]
        base = nums[0] if len(nums) >= 3 and kind == "deduction" else None
        rate = nums[1] if len(nums) >= 3 and kind == "deduction" else None
        units = nums[1] if len(nums) >= 3 and kind == "earning" else None
        r["items"].append(_item(concept, amount, kind, units, rate, base, nums[0] if len(nums) >= 3 and kind == "earning" else None))
        if "retencion a cuenta del irpf" in f:
            r["irpf_amount"], r["irpf_base"], r["irpf_rate"] = amount, base, rate
        if "coste ss empresa" in f:
            r["ss_employer"] = amount
        if "total cot retribucion" in f:
            r["in_kind_cotization"] = amount
    # Summary explicitly prints accumulated IRPF in the first column. Last two
    # values on Base IRPF are THIS receipt's deductions and monetary earnings.
    for line in layout.splitlines():
        f = _fold(line.strip())
        if f.startswith("base irpf ") and "especie" not in f:
            nums = _numbers(line)
            if len(nums) >= 3:
                r["deductions"], r["gross"] = nums[-2:]
        if f.startswith("retencion seguridad social"):
            m = re.search(r"(\d{1,2}/\d{1,2}/20\d{2})", line)
            if m:
                r["payment_date"] = _iso(m[1])
                nums = _numbers(line[:m.start()])
                if len(nums) >= 2:
                    r["net"] = nums[-1]
        if re.match(r"^\s*[-+]?\d+[.,]\d+\s+0\s+[-+]?\d+[.,]\d+", line):
            r["ss_base"] = _numbers(line)[0]
    ss_items = [i for i in r["items"] if i["kind"] == "deduction" and "cotizacion" in _fold(i["concept"])]
    if ss_items:
        r["ss_employee"] = round(sum(i["amount"] for i in ss_items), 2)
    # Some receipts omit units/base/rate; monetary gross is an independently read
    # source total and equals the taxable base for this supplied format.
    if r["irpf_base"] is None and r["gross"] is not None:
        r["irpf_base"] = r["gross"]
        r["warnings"].append("El recibo omite base/tipo junto al IRPF; se usa el total dinerario como base de este formato.")


def _navarra_new(r, text, layout):
    r["format"] = "navarra_modern"
    r["employer"] = "Clínica Universidad de Navarra"
    lines = text.splitlines()
    r["employee"] = lines[1].strip() if len(lines) > 1 else ""
    for n, line in enumerate(lines):
        if re.search(r"\d{1,2}/\d{1,2}/20\d{2}\s+a\s+\d{1,2}/\d{1,2}/20\d{2}", line):
            if n >= 2 and lines[n - 2].strip().isdigit():
                r["days"] = float(lines[n - 2].strip())
            if n + 2 < len(lines):
                r["category"] = lines[n + 2].strip()
            break
    header = re.search(r"^\s*(.+?)\s{2,}\d{1,2}/\d{1,2}/20\d{2}\s+a\s+\d{1,2}/\d{1,2}/20\d{2}\s+(\d+(?:[.,]\d+)?)\s*$", layout, re.M)
    if header:
        r["category"] = header[1].strip()
        r["days"] = float(header[2].replace(",", "."))
    in_items = False
    for line in layout.splitlines():
        f = _fold(line)
        if "concepto" in f and "deducciones" in f:
            in_items = True
            continue
        if in_items and "las cantidades" in f:
            in_items = False
        if in_items:
            m = re.match(r"\s*(\S.*?)\s{2,}(.+)$", line)
            if not m:
                continue
            concept, rest = m.groups()
            nums = _numbers(rest)
            if not nums:
                continue
            c = _fold(concept)
            if "retencion irpf" in c:
                if len(nums) >= 2:
                    r["irpf_base"], r["irpf_amount"] = nums[0], nums[-1]
                    r["irpf_rate"] = nums[1] if len(nums) >= 3 else None
                    r["items"].append(_item(concept, nums[-1], "deduction", rate=r["irpf_rate"], base=nums[0]))
            elif "coste s.social empleado" in c:
                r["ss_employee"] = nums[-1]
                # Detailed contribution rows below replace this aggregate item.
            elif len(nums) >= 2:
                # Some refunds print quantity and total but leave unit price empty.
                r["items"].append(_item(concept, nums[-1], "earning", units=nums[-2], price=nums[0] if len(nums) >= 3 else None))
        if "contingencias comunes (cc)" in f:
            pos = f.index("contingencias comunes (cc)")
            nums = _numbers(line[pos + len("Contingencias Comunes (CC)"):])
            if len(nums) >= 6:
                r["ss_base"] = nums[0]
        # Contribution data shares a row with annual accumulated amounts. Slice
        # after its concept, so accumulated values never enter monthly totals.
        for label in ("Contingencias Comunes (CC)", "Horas Extra Normales", "Cuota Solidaridad",
                      "A.T. y E.P. Cuotas IT IMS", "Desempleo Fogasa F.P", "Mec. Equidad Intergeneracional",
                      "Vacaciones", "Bonificación/Reducción"):
            pos = f.find(_fold(label))
            if pos < 0:
                continue
            nums = _numbers(line[pos + len(label):])
            if len(nums) >= 6:
                if nums[2]:
                    r["items"].append(_item(label, nums[2], "deduction", rate=nums[1], base=nums[0]))
                if nums[5]:
                    r["items"].append(_item(label + " · empresa", nums[5], "informative", rate=nums[4], base=nums[3]))
            elif label == "Cuota Solidaridad" and len(nums) == 2 and nums[0]:
                r["items"].append(_item(label, nums[0], "deduction"))
        if "totales" in f and "retencion seguridad social" in f:
            pos = f.index("totales")
            nums = _numbers(line[pos + len("totales"):])
            if len(nums) >= 2:
                r["ss_employer"] = nums[-1]
        if "total liquido" in f:
            # The base-contribution row precedes the net total on the same line.
            pos = f.index("total liquido")
            nums = _numbers(line[:pos])
            if nums:
                r["ss_base"] = nums[-1]
            nums = _numbers(line[pos:])
            if nums:
                r["net"] = nums[-1]
    # Gross / deductions are printed as a pair immediately above Total Líquido.
    ll = layout.splitlines()
    for n, line in enumerate(ll):
        if "total liquido" in _fold(line) and n:
            nums = _numbers(ll[n - 1])
            if len(nums) >= 2:
                r["gross"], r["deductions"] = nums[-2:]
    detailed = [i for i in r["items"] if i["kind"] == "deduction" and "irpf" not in _fold(i["concept"])]
    if detailed:
        actual_ss = round(sum(i["amount"] for i in detailed), 2)
        printed_ss = r["ss_employee"]
        if printed_ss is not None and abs(printed_ss - actual_ss) > .05:
            r["items"].append(_item("Coste S.Social Empleado · resumen impreso", printed_ss, "informative"))
            r["warnings"].append(f"El resumen de Seguridad Social muestra {printed_ss:.2f} €, pero el desglose de este recibo suma {actual_ss:.2f} €. Se usa el desglose; revisa la diferencia con el original.")
        r["ss_employee"] = actual_ss
    elif r["ss_employee"] is not None:
        r["items"].append(_item("Coste S.Social Empleado", r["ss_employee"], "deduction"))
    earnings = [i for i in r["items"] if i["kind"] == "earning"]
    if earnings and all("variable anual" in _fold(i["concept"]) for i in earnings):
        r["pay_type"] = "extraordinaria"


def _madrid(r, text, layout):
    r["format"] = "madrid"
    r["employer"] = "Hospital U. Puerta de Hierro Majadahonda"
    r["employee"] = ""
    m = re.search(r"\b\d{3}[A-Z]\d+\s+(.+)", text)
    if m:
        r["category"] = m[1].strip()
    if "Pagas Retroactivas" in text:
        r["pay_type"] = "atrasos"
    elif "finiquito" in _fold(text):
        r["pay_type"] = "finiquito"
    m = re.search(r"(?:\d{2}/\d{2}/20\d{2}\s*-\s*\d{2}/\d{2}/20\d{2}|Pagas Retroactivas)\s+(\d+)", text)
    if m:
        r["days"] = float(m[1])
        r["days_contributed"] = r["days"]
    m = re.search(r"D[ií]as Alta:\s*\n\s*(\d+)", text)
    if m:
        r["days"] = float(m[1])
    active = False
    for line in text.splitlines():
        if "Días Alta:" in line:
            # Body starts after this final header and its integer value.
            active = True
            continue
        if not active:
            continue
        if re.match(r"\s*[\d.,]+\s+[\d.,]+\s+[\d.,]+", line) and not re.search(r"[A-Za-zÁÉÍÓÚáéíóú]", line):
            break
        m = re.match(r"\s*(.*?)\s*([A-Za-zÁÉÍÓÚÜÑáéíóúüñ].*?)\s+([-+\d.,]+)\s*$", line)
        if not m:
            continue
        prefix, concept, amount = m.groups()
        if not re.fullmatch(MONEY, amount):
            continue
        nums = _numbers(prefix)
        f = _fold(concept)
        kind = "informative" if "coste s.s. empresa" in f else "deduction" if "cotiz." in f or "retencion" in f else "earning"
        base = nums[-1] if len(nums) >= 2 and kind == "deduction" else None
        rate = nums[0] if kind == "deduction" and len(nums) >= 2 else None
        units = nums[0] if kind == "earning" and len(nums) >= 2 else None
        value = _money(amount)
        r["items"].append(_item(concept, value, kind, units, rate, base, nums[-1] if nums and kind == "earning" else None))
        if "retencion" in f:
            r["irpf_amount"], r["irpf_base"], r["irpf_rate"] = value, base, rate
        if "coste s.s. empresa" in f:
            r["ss_employer"] = value
    r["ss_employee"] = round(sum(i["amount"] for i in r["items"] if i["kind"] == "deduction" and "cotiz." in _fold(i["concept"])), 2)
    ll = layout.splitlines()
    for n, line in enumerate(ll):
        if "REM. TOTAL" in line and n + 1 < len(ll):
            nums = _numbers(ll[n + 1])
            if len(nums) >= 7:
                r["ss_base"], r["irpf_base"], r["gross"], r["deductions"] = nums[2], nums[4], nums[5], nums[6]
        if "Tipo de pago:" in line:
            nums = _numbers(line)
            if nums:
                r["net"] = nums[-1]


def _canarias(r, text, layout):
    r["format"] = "canarias"
    r["employer"] = "Hospital Universitario de G.C. Doctor Negrín"
    r["employee"] = ""
    m = re.search(r"Puesto de trabajo\s*:\s*(.+)", layout)
    if m:
        r["category"] = m[1].strip()
    m = re.search(r"D[ií]as Alta N[oó]mina:\s*([\d.]+)", layout)
    if m:
        r["days"] = float(m[1])
    m = re.search(r"N[oó]mina de pago\s*:\s*(\d+) de ([A-Za-záéíóú]+) de (20\d{2})", layout)
    if m:
        months = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]
        if _fold(m[2]) in months:
            r["payment_date"] = _iso(f"{m[1]}/{months.index(_fold(m[2])) + 1}/{m[3]}")
    active = False
    informative = False
    for line in layout.splitlines():
        f = _fold(line)
        if "unidades" in f and "concepto" in f:
            active = True
            continue
        if "total mes" in f:
            nums = _numbers(line)
            if len(nums) >= 2:
                r["gross"], r["deductions"] = nums[-2:]
            active = False
        elif "total atrasos" in f:
            nums = _numbers(line)
            if len(nums) >= 2 and r["gross"] is not None:
                r["gross"] += nums[-2]
                r["deductions"] += nums[-1]
                if any(nums[-2:]):
                    r["warnings"].append("El recibo incluye atrasos además del total mensual; revisar su imputación fiscal.")
        elif "liquido........" in f:
            nums = _numbers(line)
            if nums:
                r["net"] = nums[-1]
        if not active:
            continue
        if "conceptos informativos" in f:
            informative = True
            continue
        m = re.match(r"\s*(.*?)\s*([A-Za-zÁÉÍÓÚÜÑáéíóúüñ].*?)\s{2,}([-+\d.,]+)\s*$", line)
        if not m or not re.fullmatch(MONEY, m[3]):
            continue
        prefix, concept, amount = m.groups()
        nums = _numbers(prefix)
        c = _fold(concept)
        kind = "informative" if informative else "deduction" if any(x in c for x in ("irpf", "contingencias comunes", "cotiz.", "desempleo")) else "earning"
        base = nums[1] if len(nums) >= 2 and kind == "deduction" else None
        rate = nums[0] if len(nums) >= 2 and kind == "deduction" else None
        value = _money(amount)
        r["items"].append(_item(concept, value, kind, nums[0] if nums and kind == "earning" else None, rate, base, nums[1] if len(nums) >= 2 and kind == "earning" else None))
        if "irpf" in c:
            r["irpf_base"], r["irpf_amount"], r["irpf_rate"] = base, value, rate
        if "coste ss" in c:
            r["ss_employer"] = value
        if "contingencias comunes" in c and kind == "deduction":
            r["ss_base"] = base
    r["ss_employee"] = round(sum(i["amount"] for i in r["items"] if i["kind"] == "deduction" and "irpf" not in _fold(i["concept"])), 2)


def _validate(r):
    earnings = [i for i in r["items"] if i["kind"] == "earning"]
    deductions = [i for i in r["items"] if i["kind"] == "deduction"]
    if earnings:
        r["remuneration_total"] = round(sum(i["amount"] for i in earnings if i["amount"] > 0), 2)
        r["exempt_in_kind"] = round(-sum(i["amount"] for i in earnings if i["amount"] < 0 and any(s in _fold(i["concept"]) for s in ("ticket", "flex"))), 2)
    if r["irpf_rate"] is None and r["irpf_amount"] is not None and r["irpf_base"]:
        r["irpf_rate"] = round(r["irpf_amount"] / r["irpf_base"] * 100, 2)
        r["warnings"].append("Tipo IRPF calculado a partir del importe retenido y la base; no impreso en el recibo.")
    failures = []
    for field in ("gross", "net", "deductions", "irpf_base", "irpf_amount", "ss_employee"):
        if r[field] is None:
            failures.append(f"No se ha podido leer el campo {field}.")
    def check(actual, expected, message):
        if actual is not None and abs(actual - expected) > 0.05:
            failures.append(message)
    if r["gross"] is not None and r["deductions"] is not None:
        check(r["net"], r["gross"] - r["deductions"], "El líquido no coincide con devengos menos deducciones.")
    if earnings:
        check(r["gross"], sum(i["amount"] for i in earnings), "Los conceptos de devengo no coinciden con el total dinerario.")
    else:
        failures.append("No se han reconocido los conceptos retributivos.")
    if deductions:
        check(r["deductions"], sum(i["amount"] for i in deductions), "Los conceptos de deducción no coinciden con el total descontado.")
    else:
        failures.append("No se han reconocido las deducciones.")
    if r["irpf_rate"] is not None and r["irpf_base"] is not None:
        check(r["irpf_amount"], round(r["irpf_base"] * r["irpf_rate"] / 100, 2), "El tipo IRPF y su base no concilian con el importe retenido.")
    if not r["year"] or not 1 <= r["month"] <= 12:
        failures.append("No se ha identificado el ejercicio o mes del documento.")
    r["warnings"].extend(failures)
    # Nonfatal derivation notices remain visible while arithmetic can verify.
    r["status"] = "review" if failures or any("no coincide" in w for w in r["warnings"]) else "verified"
    return r


def extract_payroll(path: Path) -> dict:
    """Read one original file; return review state instead of fabricating totals."""
    path = Path(path)
    r = _blank(path)
    try:
        header = path.read_bytes()[:1024]
        if b"%PDF-" not in header:
            r["warnings"].append("El archivo tiene extensión PDF pero contiene una página HTML del portal de acceso. Vuelve a descargar la nómina o completa los datos manualmente." if b"html" in header.lower() or b"xml" in header.lower() else "El archivo no tiene una cabecera PDF válida. Sustituye el documento o completa los datos manualmente.")
            return r
        reader = PdfReader(path)
        if __package__:
            from .type3_text import extract_known_type3
        else:
            from type3_text import extract_known_type3
        recovered = extract_known_type3(reader)
        if recovered:
            r["raw_text"] = r["raw_layout"] = recovered
            r["warnings"].append("Texto recuperado localmente desde una fuente Type3 conocida sin mapa Unicode. Los importes se contrastan con los totales impresos.")
        else:
            r["raw_text"] = "\n\n".join(page.extract_text() or "" for page in reader.pages)
            r["raw_layout"] = "\n\n".join(page.extract_text(extraction_mode="layout") or "" for page in reader.pages)
        text, layout = r["raw_text"], r["raw_layout"]
        if not text.strip():
            r["warnings"].append("PDF sin texto extraíble; puede ser una imagen escaneada. Requiere OCR externo o registro manual.")
            return r
        _dates(r, text, layout)
        if "Puerta de Hierro" in text:
            _madrid(r, text, layout)
        elif "Doctor Negr" in text or "Dr Negrin" in text:
            _canarias(r, text, layout)
        elif "CLASIFICACIÓN PROFESIONAL" in text and "unav.es" in text:
            _navarra_new(r, text, layout)
        elif "Clínica Universidad de Navarra" in text:
            _navarra_old(r, text, layout)
        else:
            r["warnings"].append("Formato de nómina no reconocido. Se conserva el texto para revisión manual.")
        return _validate(r)
    except Exception as exc:
        r["warnings"].append(f"No se ha podido extraer el PDF ({type(exc).__name__}). Sustituye el documento o completa los datos manualmente.")
        return r
