"""Same local PDF parser as Windows, packaged for the browser. No network IO."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from parser import extract_payroll

def simulate_scenario(payload_json):
    from tax import simulate
    try:
        payload=json.loads(payload_json)
        # The phone uses the same conservative scope as the desktop UI.
        payload.update(other_work_expenses=0,deductible_expenses=2000,reductions=0,
                       state_deductions=0,regional_deductions=0)
        return json.dumps({'result':simulate(payload)},ensure_ascii=False,allow_nan=False)
    except (ValueError,TypeError) as error:
        return json.dumps({'error':str(error)},ensure_ascii=False)


def parse_document(path):
    path = Path(path)
    data = path.read_bytes()
    if len(data) > 20 * 1024 * 1024:
        raise ValueError('El PDF supera el máximo de 20 MB por documento.')
    if b'%PDF-' in data[:1024]:
        from pypdf import PdfReader
        reader = PdfReader(path)
        if reader.is_encrypted:
            raise ValueError('El PDF está protegido. Guarda una copia sin contraseña e impórtala.')
        if len(reader.pages) > 30:
            raise ValueError('Selecciona las nóminas como PDF individuales, de hasta 30 páginas.')
    record = extract_payroll(path)
    # Filenames from a mail attachment often have no AAAAMM prefix.
    if not record['month']:
        date = record.get('period_end') or record.get('payment_date')
        if date:
            record['year'], record['month'] = map(int, date.split('-')[:2])
    if not record['month'] or not record['year']:
        record['year'] = record['month'] = 0
        record['warnings'].append('Indica el año y mes en «Revisar datos». No se ha supuesto ninguna fecha.')
        record['status'] = 'review'
    for key in ('raw_text', 'raw_layout', 'employee'):
        record.pop(key, None)
    digest = hashlib.sha256(data).hexdigest()
    record.update(id='pdf-' + digest, source_hash=digest, filename=path.name,
                  origin='pdf', updated_at=datetime.now(timezone.utc).isoformat())
    return json.dumps(record, ensure_ascii=False, allow_nan=False)
